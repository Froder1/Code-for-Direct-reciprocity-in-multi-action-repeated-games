tic
% Calculate the fixation probability of all memory-1 strategies under the four actions C X1 X2 D
%Parameters
b=1.6;c=1;
e=0.01;
beta=10; kaba1=2/3; kaba2=0;

fix_p_L=zeros(65536); 
fix_p_L=single(fix_p_L); 
fix_p_u=zeros(65536); 
fix_p_u=single(fix_p_u);

n_actions = 4;    
n_outcomes = 8;    
% CC=1, CX1=2, CX2=3, CD=4, X1C=5, X1X1=6, X1X2=7 X1D=8
% X2C=9, X2X1=10, X2X2=11, X2D=12, X2C=13, X2X1=14, X2X2=15X2D=16
n_strategies = n_actions^n_outcomes;  

strategies = zeros(n_strategies, n_outcomes);

for i = 0:n_strategies-1
    strategy = dec2base(i, n_actions, n_outcomes) - '0'; 
    strategies(i+1, :) = strategy;  
end

% Completely expand the matrix to facilitate calculation
strategies_extend=zeros(n_actions^n_outcomes,16); 

strategies_extend(:, 1) = strategies(:, 1);   
strategies_extend(:, 5) = strategies(:, 3);   
strategies_extend(:, 9) = strategies(:, 5);   
strategies_extend(:, 13) = strategies(:, 7);  

strategies_extend(:, 2:4) = repmat(strategies(:, 2), 1, 3);  
strategies_extend(:, 6:8) = repmat(strategies(:, 4), 1, 3);  
strategies_extend(:, 10:12) = repmat(strategies(:, 6), 1, 3); 
strategies_extend(:, 14:16) = repmat(strategies(:, 8), 1, 3); 


self_pay=zeros(65536,1); 

parfor i=1:65536
    p=strategies_extend(i,:);
    [self_pay(i), ~]=cal_pay(p,p,b,c,e,kaba1,kaba2);
end
self_coop=get_self_cooprate(kaba1, kaba2, e);

parfor i=1:65536^2
    pi_m1=zeros(2);
    pi_m2=zeros(2);
    col=fix((i-1)/65536)+1;
    row=mod(i-1,65536)+1;   
    if row>col 
       p=strategies_extend(col,:); q=strategies_extend(row,:);
       [Pay_col ,Pay_row]=cal_pay(p,q,b,c,e,kaba1,kaba2);
       pi_m1(1,1)=self_pay(col);pi_m1(2,2)=self_pay(row);   
       pi_m1(1,2)=Pay_col; pi_m1(2,1)=Pay_row;
       Rho1=CalcRho(pi_m1,beta); 
       Rho1=single(Rho1);
       fix_p_L(i)=Rho1;

       pi_m2(1,1)=pi_m1(2,2);
       pi_m2(2,2)=pi_m1(1,1);
       pi_m2(1,2)=pi_m1(2,1);
       pi_m2(2,1)=pi_m1(1,2);
       Rho2=CalcRho(pi_m2,beta);
       Rho2=single(Rho2);
       fix_p_u(i)=Rho2;
    end
end

fix_p_L=fix_p_L+fix_p_u';


clear fix_p_u

save("Data_1.mat","fix_p_L","self_coop","b","e","beta","kaba1","kaba2")
toc



