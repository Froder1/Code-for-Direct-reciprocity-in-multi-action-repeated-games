% 65536 memory-1 strategies（ C X1 X2 D）

nGen=10^9; % The number of iterations for each independent experiment
time=10; % Number of independent experiments
Coop_rate=zeros(nGen/100,1); % cooperation rate
Freq=zeros(65536,1);  
tic 
for  simulation= 1: time
 disp(simulation)
Res=65536;
Coop_rate(1)=Coop_rate(1)+self_coop(65536);   % ALLD
Freq(1)=Freq(1)+1;  
    for evo_step=2:nGen
        Mut=randi(65536);
        rho=fix_p_L(Res,Mut);
         if rand(1)<rho % If fixation occurs
             Res=Mut; % Resident strategy is replaced by mutant strategy
         end
        Freq(Res)=Freq(Res)+1;
         if mod(evo_step,100)==0
             Coop_rate(evo_step/100)=Coop_rate(evo_step/100)+self_coop(Res);
         end
    end
end 
Coop_rate=Coop_rate/time; 
Freq=Freq/(time*nGen);
coop_3000(3)=mean(Coop_rate);
toc 
