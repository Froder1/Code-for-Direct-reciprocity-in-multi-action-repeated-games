tic
%Get the average cooperation rate of the population under different kaba and different b values

%parameters
epsilon=0.01; %Error rate
beta=10;  
c=1;   
ave_coop_1=zeros(11,11); 
n_actions = 3;    
n_outcomes = 9;    
n_strategies = n_actions^n_outcomes;  % 3^9 个策略

strategies = zeros(n_strategies, n_outcomes);

for i = 0:n_strategies-1
    strategy = dec2base(i, n_actions, n_outcomes) - '0'; % 将数字转换为三进制表示，并转化为矩阵
    strategies(i+1, :) = strategy;  % 将策略存入矩阵
end
%consider: p_CD1=p_CD2; p_D1D1=p_D1D2; p_D2D1=p_D2D2; 
rows = find((strategies(:, 2) == strategies(:, 3)) & (strategies(:, 5) == strategies(:, 6)) & (strategies(:, 8) == strategies(:, 9)));
strategies=strategies(rows,:);

for j=1:11
    b=1.0+(j-1)*0.1; 
    for k=1:11
        kaba=(k-1)*0.1;
        fix_p_L=zeros(729);
        fix_p_u=zeros(729);
        self_pay=zeros(729,1); 
        parfor i=1:729
            p_str=strategies(i,:);
            [self_pay(i), ~]=cal_pay(p_str,p_str,b,c,epsilon,kaba);
        end
        self_c_rate=get_self_cooprate(kaba,epsilon);
        parfor i=1:729^2
            pi_m1=zeros(2);
            pi_m2=zeros(2);
            col=fix((i-1)/729)+1;  
            row=mod(i-1,729)+1;   
            if row>col 
                p=strategies(col,:); q=strategies(row,:);
                [Pay_col, Pay_row]=cal_pay(p,q,b,c,epsilon,kaba)
                pi_m1(1,1)=self_pay(col);pi_m1(2,2)=self_pay(row);  
                pi_m1(1,2)=Pay_col; pi_m1(2,1)=Pay_row;
                Rho1=CalcRho(pi_m1,beta); 
                fix_p_L(i)=Rho1;
                pi_m2(1,1)=pi_m1(2,2);
                pi_m2(2,2)=pi_m1(1,1);
                pi_m2(1,2)=pi_m1(2,1);
                pi_m2(2,1)=pi_m1(1,2);
                Rho2=CalcRho(pi_m2,beta); 
                fix_p_u(i)=Rho2;
            end
        end

        fix_p_L=fix_p_L+fix_p_u';
        clear fix_p_u
        for i=1:729
            fix_p_L(i,i)=1-sum(fix_p_L(i,:));
        end
        v=null(fix_p_L'-eye(729));
        v=v/sum(v);
        ave_coop_1(j,k)=v'*self_c_rate;
    end
end

toc