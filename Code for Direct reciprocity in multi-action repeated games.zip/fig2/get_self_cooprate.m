function self_coop=get_self_cooprate(kaba,epsilon)

% Calculate the cooperation rate when the strategy is self-playing

n_actions = 3;     
n_outcomes = 9;   
n_strategies = n_actions^n_outcomes;  
self_coop=zeros(729,1);

strategies = zeros(n_strategies, n_outcomes);

for i = 0:n_strategies-1
    strategy = dec2base(i, n_actions, n_outcomes) - '0'; 
    strategies(i+1, :) = strategy;  
end

%consider: p_CD1=p_CD2; p_D1D1=p_D1D2; p_D2D1=p_D2D2; 
% 
rows = find((strategies(:, 2) == strategies(:, 3)) & (strategies(:, 5) == strategies(:, 6)) & (strategies(:, 8) == strategies(:, 9)));
strategies=strategies(rows,:);
for ii=1:1:729
strategy_p=strategies(ii,:);
strategy_q=strategy_p; 


    n_states = 9;
 
    transition_matrix = zeros(n_states, n_states);
   
    for i = 1:n_states
       
         expected_action_p = strategy_p(i);
      
         Decision_bit_map_q=[1, 4, 7, 2, 5, 8, 3, 6, 9];
         actual_bit=Decision_bit_map_q(i);
         expected_action_q = strategy_q(actual_bit);
        for j = 1:n_states
            
            action_map_p = [0, 0, 0, 1, 1, 1, 2, 2, 2]; 
            action_map_q = [0, 1, 2, 0, 1, 2, 0, 1, 2]; 
            actual_action_p = action_map_p(j);
            actual_action_q = action_map_q(j);

       
            if expected_action_p == actual_action_p && expected_action_q == actual_action_q
            
                transition_matrix(i, j) = (1 - epsilon)^2;
            elseif expected_action_p == actual_action_p && expected_action_q ~= actual_action_q
             
                transition_matrix(i, j) = (1 - epsilon) * (epsilon / 2);
            elseif expected_action_p ~= actual_action_p && expected_action_q == actual_action_q
            
                transition_matrix(i, j) = (1 - epsilon) * (epsilon / 2);
            else
          
                transition_matrix(i, j) = (epsilon^2) / 4;
            end
        end
    end


    v=null(transition_matrix'-eye(n_states)); 
    v=v/sum(v); 
    self_coop(ii)=v'*[1;(1+kaba)/2;1/2;(1+kaba)/2;kaba;kaba/2;1/2;kaba/2;0];
end 
end 