% Given any two strategies and errors, calculate the payoffs of these two strategies
function [pay_p, pay_q]=cal_pay(strategy_p,strategy_q,b,c,epsilon,kaba)
%strategy_p, strategy_q, epsilon
    % number of the states
    n_states = 9;
    transition_matrix = zeros(n_states, n_states);
    % For all state
    for i = 1:n_states
         expected_action_p = strategy_p(i);
         Decision_bit_map_q=[1, 4, 7, 2, 5, 8, 3, 6, 9];
         actual_bit=Decision_bit_map_q(i);
         expected_action_q = strategy_q(actual_bit);
        for j = 1:n_states
            % Number the states
            % CC = 1, CD1 = 2, CD2 = 3, D1C = 4, D1D1 = 5, D1D2 = 6, D2C = 7, D2D1 = 8, D2D2 = 9
            action_map_p = [0, 0, 0, 1, 1, 1, 2, 2, 2]; 
            action_map_q = [0, 1, 2, 0, 1, 2, 0, 1, 2]; 
            actual_action_p = action_map_p(j);
            actual_action_q = action_map_q(j);

            % Transition probability
            if expected_action_p == actual_action_p && expected_action_q == actual_action_q
                
                transition_matrix(i, j) = (1 - epsilon)^2;
            elseif expected_action_p == actual_action_p && expected_action_q ~= actual_action_q
                
                transition_matrix(i, j) = (1 - epsilon) * (epsilon / 2);
            elseif expected_action_p ~= actual_action_p && expected_action_q == actual_action_q
              
                transition_matrix(i, j) = (1 - epsilon) * (epsilon / 2);
            else
                
                transition_matrix(i, j) = (epsilon^2) / 4;
            end
        end
    end
    v=null(transition_matrix'-eye(n_states)); 
    v=v/sum(v); 
    
    pi_p = [b - c, kaba * b - c, -c, b - kaba * c, kaba * b - kaba * c, -kaba * c, b, kaba * b, 0];
    pi_q = [b - c, b - kaba * c, b, kaba * b - c, kaba * b - kaba * c, kaba * b, -c, -kaba * c, 0];
    
    %payoff of the p and q
    pay_p=pi_p*v;
    pay_q=pi_q*v;
end