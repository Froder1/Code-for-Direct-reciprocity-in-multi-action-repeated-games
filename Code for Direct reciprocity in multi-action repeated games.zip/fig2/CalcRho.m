function Rho=CalcRho(PayM,beta)
% Calculates the fixation probability of one S1 mutant in an S2 population
S1=1; S2=2;
N=100; 
alpha=zeros(1,N-1);
for j=1:N-1 % j.. Number of mutants in the population
    pi1=(j-1)/(N-1)*PayM(S1,S1)+(N-j)/(N-1)*PayM(S1,S2); % Payoff mutant
    pi2=j/(N-1)*PayM(S2,S1)+(N-j-1)/(N-1)*PayM(S2,S2); % Payoff resident 
    alpha(j)=exp(-beta*(pi1-pi2));
end
Rho=1/(1+sum(cumprod(alpha))); % Calculating the fixation probability according to formula given in SI
end